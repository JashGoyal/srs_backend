package com.srsense.ai.dto;

import java.util.Map;

public class SrsSavedto {
    private Map<String, Object> aiResponse;

    public Map<String, Object> getAiResponse() {
        return aiResponse;
    }

    public void setAiResponse(Map<String, Object> aiResponse) {
        this.aiResponse = aiResponse;
    }
}
