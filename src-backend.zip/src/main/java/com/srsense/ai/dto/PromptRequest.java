package com.srsense.ai.dto;

import lombok.Data;

@Data
public class PromptRequest {
private String prompt;
}
